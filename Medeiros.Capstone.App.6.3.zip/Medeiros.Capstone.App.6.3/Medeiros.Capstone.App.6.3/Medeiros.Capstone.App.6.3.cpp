// Medeiros.Capstone.App.6.3.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>

using namespace std;

//Node class represents a single node in the linked list
class Node {
public:
    int data;
    Node* next;

    //Constructor
    Node(int value) : data(value), next(nullptr) {}
};

//Linked list class manages the linked list operations
class LinkedList {
private:
    Node* head;

public:
    //Contructor
    LinkedList() : head(nullptr) {}

    //Destructor
    ~LinkedList() {
        //Delete every node in the list
        Node* current = head;
        while (current != nullptr) {
            Node* next = current->next;
            delete current;
            current = next;
        }
        head = nullptr;
    }

    //Insert a node at the beginning of a list
    void insert(int value) {
        Node* newNode = new Node(value);
        newNode->next = head;
        head = newNode;
    }

    //Display all elements in the list
    void display() {
        Node* current = head;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

int main()
{
    //Create a linked list
    LinkedList myList;

    //Insert elements into the list
    myList.insert(5);
    myList.insert(10);
    myList.insert(15);

    //Display elements of the list
    cout << "Linked List Elements:";
    myList.display();

    return 0;
}